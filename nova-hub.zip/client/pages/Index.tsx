import { useState, useEffect } from "react";
import SuccessPopup from "@/components/SuccessPopup";
import ErrorPopup from "@/components/ErrorPopup";
import ValidationScreen from "@/components/ValidationScreen";

type ScreenType = "start" | "question" | "validating" | "success" | "discount";

interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
}

const questions: Question[] = [
  {
    id: 1,
    text: "Qual foi o ano de lançamento do Free Fire?",
    options: ["2015", "2017", "2020"],
    correctAnswer: 1,
  },
  {
    id: 2,
    text: "Qual granada pode ser usada como escudo?",
    options: ["Granada de Luz", "Granada de Gelo", "Granada de Fumaça"],
    correctAnswer: 1,
  },
  {
    id: 3,
    text: "Qual dessas opções é uma arma de contato?",
    options: ["Panela", "MP-40", "AWM"],
    correctAnswer: 0,
  },
];

export default function Index() {
  const [screen, setScreen] = useState<ScreenType>("start");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showErrorPopup, setShowErrorPopup] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);


  const handleStartQuiz = () => {
    setCurrentQuestion(0);
    setShowErrorPopup(false);
    setShowSuccessPopup(false);
    setScreen("question");
  };

  const handleSelectAnswer = (answerIndex: number) => {
    const question = questions[currentQuestion];
    const isCorrect = answerIndex === question.correctAnswer;

    if (isCorrect) {
      // Correct answer - show success popup with next button
      setShowErrorPopup(false);
      setShowSuccessPopup(true);
    } else {
      // Wrong answer - show error popup with try again button
      setShowErrorPopup(true);
      setShowSuccessPopup(false);
    }
  };

  const handleNextQuestion = () => {
    setShowSuccessPopup(false);
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Show validation screen when all questions are answered
      setScreen("validating");
    }
  };

  const handleValidationComplete = () => {
    setScreen("success");
  };

  const handleTryAgain = () => {
    setShowErrorPopup(false);
  };

  const handleContinue = () => {
    setScreen("discount");
  };

  const handleRetry = () => {
    handleStartQuiz();
  };

  const handleClaimReward = () => {
    // Handle claiming diamonds
    alert("Diamantes resgatados! Verifique sua conta.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-950 via-orange-900 to-yellow-900 flex items-center justify-center p-3 sm:p-4">
      {/* Success Popup */}
      <SuccessPopup isVisible={showSuccessPopup} onNext={handleNextQuestion} />

      {/* Error Popup */}
      <ErrorPopup isVisible={showErrorPopup} onTryAgain={handleTryAgain} />

      {/* Validation Screen */}
      <ValidationScreen isVisible={screen === "validating"} onComplete={handleValidationComplete} />

      <div className="w-full max-w-lg" style={{ display: screen === "validating" ? "none" : "block" }}>
        {/* START SCREEN */}
        {screen === "start" && (
          <div className="animate-fade-in">
            <div className="text-center">
              {/* Header */}
              <div className="mb-6 sm:mb-8">
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-white drop-shadow-lg mb-2">
                  Free Fire
                </h1>
                <p className="text-xl sm:text-2xl md:text-3xl font-bold text-yellow-300">
                  Comece o Desafio! 💎
                </p>
              </div>

              {/* Description */}
              <div className="bg-black/40 backdrop-blur-sm rounded-2xl p-6 sm:p-8 mb-6 sm:mb-8 border-2 border-orange-500">
                <p className="text-white text-base sm:text-lg md:text-xl font-semibold mb-4">
                  O Free Fire está celebrando aniversário. Responda 3 perguntas e desbloqueie 90% de Desconto.
                </p>
                <div className="flex justify-center gap-3 text-2xl sm:text-3xl">
                  🎮 🔥 🎁
                </div>
              </div>

              {/* Start Button */}
              <button
                onClick={handleStartQuiz}
                className="inline-block bg-gradient-to-r from-red-600 via-orange-500 to-yellow-500 hover:from-red-700 hover:via-orange-600 hover:to-yellow-600 text-white font-black text-lg sm:text-xl md:text-2xl px-8 sm:px-12 py-3 sm:py-4 rounded-xl shadow-2xl transition-all transform hover:scale-105 border-2 border-yellow-300 active:scale-95"
              >
                INICIAR DESAFIO
              </button>

              <p className="text-gray-300 text-xs sm:text-sm mt-4 sm:mt-6">
                Você tem 5 minutos para completar o desafio
              </p>
            </div>
          </div>
        )}

        {/* QUESTION SCREEN */}
        {screen === "question" && (
          <div className="animate-fade-in">
            <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-5 sm:p-8 md:p-12 border-2 border-orange-500">
              {/* Progress */}
              <div className="mb-6 sm:mb-8">
                <div className="flex justify-between items-center mb-3 sm:mb-4">
                  <span className="text-yellow-300 font-bold text-base sm:text-lg">
                    Pergunta {currentQuestion + 1} de {questions.length}
                  </span>
                  <div className="w-24 sm:w-32 bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all duration-300"
                      style={{
                        width: `${((currentQuestion + 1) / questions.length) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Question Text */}
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-6 sm:mb-8 text-center">
                {questions[currentQuestion].text}
              </h2>

              {/* Answer Options */}
              <div className="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleSelectAnswer(index)}
                    className="w-full bg-gradient-to-r from-orange-700/80 to-red-700/80 hover:from-orange-600 hover:to-red-600 text-white font-bold text-base sm:text-lg md:text-xl p-5 sm:p-6 rounded-xl border-2 border-orange-400 hover:border-yellow-300 transition-all transform hover:scale-105 active:scale-95 text-center"
                  >
                    {option}
                  </button>
                ))}
              </div>

              <p className="text-center text-gray-400 text-xs sm:text-sm">
                Selecione uma resposta para continuar
              </p>
            </div>
          </div>
        )}

        {/* SUCCESS SCREEN - Parabéns */}
        {screen === "success" && (
          <div className="animate-scale-in">
            <div className="text-center">
              {/* Success Badge */}
              <div className="mb-6 sm:mb-8 text-6xl sm:text-7xl md:text-8xl animate-pulse">
                ✅
              </div>

              <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-yellow-300 mb-3 sm:mb-4">
                Parabéns! 🎉
              </h2>

              <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 sm:p-8 mb-6 sm:mb-8 border-2 border-orange-500">
                <p className="text-white text-base sm:text-lg mb-3 sm:mb-4">
                  Você respondeu corretamente todas as perguntas!
                </p>
                <p className="text-yellow-300 font-bold text-lg sm:text-xl">
                  Seu desconto de 90% já está ativo 🎁
                </p>
              </div>

              {/* Continue Button */}
              <button
                onClick={handleContinue}
                className="inline-block bg-gradient-to-r from-red-600 via-orange-500 to-yellow-500 hover:from-red-700 hover:via-orange-600 hover:to-yellow-600 text-white font-black text-lg sm:text-xl md:text-2xl px-8 sm:px-10 py-3 sm:py-4 rounded-xl shadow-2xl transition-all transform hover:scale-105 border-2 border-yellow-300 active:scale-95"
              >
                CONTINUAR 👉
              </button>
            </div>
          </div>
        )}

        {/* DISCOUNT SCREEN */}
        {screen === "discount" && (
          <div className="animate-scale-in">
            <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-6 sm:p-10 border-2 border-orange-500 shadow-2xl">
              <div className="text-center">
                {/* Header */}
                <div className="mb-6 sm:mb-8">
                  <h2 className="text-3xl sm:text-4xl font-black text-yellow-300 mb-2">
                    🎮 Desafio Concluído!
                  </h2>
                </div>

                {/* Illustration Area */}
                <div className="mb-8 sm:mb-10 relative h-40 sm:h-48 flex items-center justify-center">
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F811775ce0d4d4bc0939c92adad005ef2%2Fa26221b7abd74912912f7fc7d6485265?format=webp&width=800"
                    alt="Baú de diamantes"
                    className="h-full w-auto object-contain drop-shadow-2xl"
                  />
                </div>

                {/* Main Achievement */}
                <div className="mb-6 sm:mb-8">
                  <p className="text-gray-300 text-sm sm:text-base font-semibold mb-2">
                    Você desbloqueou:
                  </p>
                  <h3 className="text-4xl sm:text-5xl font-black text-orange-400">
                    90% OFF!
                  </h3>
                </div>

                {/* Rewards Info */}
                <div className="bg-black/60 backdrop-blur-sm rounded-2xl p-6 sm:p-8 mb-8 border border-orange-400/50">
                  <p className="text-white font-black text-xl sm:text-2xl mb-2">
                    Você ganhou
                  </p>
                  <p className="text-yellow-300 font-black text-3xl sm:text-4xl mb-3">
                    5.280 diamantes
                  </p>
                  <p className="text-orange-300 font-bold text-base sm:text-lg">
                    por apenas R$ 9,90
                  </p>
                  <p className="text-gray-400 text-xs sm:text-sm mt-4 italic">
                    Pague comparando diamantes e aproveite os melhores itens do evento!
                  </p>
                </div>

                {/* Claim Button */}
                <button
                  onClick={handleClaimReward}
                  className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-black text-lg sm:text-xl md:text-2xl px-8 py-4 sm:py-5 rounded-2xl shadow-2xl transition-all transform hover:scale-105 active:scale-95 border-2 border-orange-300"
                >
                  RESGATAR CUPOM
                </button>

                <p className="text-gray-400 text-xs sm:text-sm mt-5 sm:mt-6">
                  Aproveite seu desconto agora mesmo!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
