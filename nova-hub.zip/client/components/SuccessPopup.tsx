import { useEffect, useState } from "react";

interface SuccessPopupProps {
  isVisible: boolean;
  onNext?: () => void;
}

export default function SuccessPopup({ isVisible, onNext }: SuccessPopupProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(isVisible);
  }, [isVisible]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
      {/* Backdrop blur */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm pointer-events-auto" />

      {/* Popup */}
      <div className="animate-scale-in relative bg-gradient-to-br from-green-500 via-emerald-500 to-green-600 rounded-3xl p-8 sm:p-12 shadow-2xl border-4 border-green-200 max-w-sm pointer-events-auto z-10">
        <div className="text-center">
          <div className="text-6xl sm:text-7xl mb-4 sm:mb-6">✅</div>
          <h3 className="text-3xl sm:text-4xl font-black text-white mb-2">
            Acertou em cheio! 🔥
          </h3>
          <p className="text-lg sm:text-xl text-green-50 font-bold mb-8">
            Continue assim, tá indo bem!
          </p>

          {/* Next Question Button */}
          <button
            onClick={onNext}
            className="w-full bg-white hover:bg-green-50 text-green-600 font-black text-lg sm:text-xl px-6 sm:px-8 py-3 sm:py-4 rounded-xl shadow-lg transition-all transform hover:scale-105 active:scale-95"
          >
            PRÓXIMA PERGUNTA 👉
          </button>
        </div>
      </div>
    </div>
  );
}
