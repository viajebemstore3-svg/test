import { useEffect, useState } from "react";

interface ValidationScreenProps {
  isVisible: boolean;
  onComplete?: () => void;
}

const avatars = ["👨", "👩", "👨‍🦱", "👩‍🦱", "👨‍🦲", "👩‍🦲"];

export default function ValidationScreen({
  isVisible,
  onComplete,
}: ValidationScreenProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!isVisible) {
      setProgress(0);
      return;
    }

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => onComplete?.(), 500);
          return 100;
        }
        return prev + Math.random() * 30;
      });
    }, 300);

    return () => clearInterval(interval);
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-950 via-orange-900 to-yellow-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="animate-fade-in">
          <div className="text-center">
            {/* Title */}
            <h2 className="text-3xl sm:text-4xl font-black text-yellow-300 mb-8">
              Analisando suas respostas...
            </h2>

            {/* Avatars Grid */}
            <div className="grid grid-cols-3 gap-4 mb-10">
              {avatars.map((avatar, idx) => (
                <div
                  key={idx}
                  className="bg-black/50 backdrop-blur-sm rounded-2xl p-4 border-2 border-orange-400 flex flex-col items-center gap-2"
                  style={{
                    opacity: progress > (idx * 16) ? 1 : 0.3,
                    transition: "opacity 0.3s ease-out",
                  }}
                >
                  <div className="text-4xl">{avatar}</div>
                  <p className="text-gray-300 text-xs font-bold">
                    Verificando...
                  </p>
                </div>
              ))}
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="bg-black/50 backdrop-blur-sm rounded-full h-4 border-2 border-orange-400 overflow-hidden mb-4">
                <div
                  className="bg-gradient-to-r from-orange-500 to-red-500 h-full transition-all duration-500"
                  style={{ width: `${Math.min(progress, 100)}%` }}
                ></div>
              </div>
              <p className="text-yellow-300 font-black text-2xl">
                {Math.floor(Math.min(progress, 100))}%
              </p>
            </div>

            {/* Status Message */}
            <p className="text-gray-300 text-sm sm:text-base font-semibold">
              Verificando ID da conta...
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
