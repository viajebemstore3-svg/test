import { useEffect, useState } from "react";

interface SuccessBannerProps {
  isVisible: boolean;
  onHide?: () => void;
}

export default function SuccessBanner({ isVisible, onHide }: SuccessBannerProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(isVisible);

    if (isVisible) {
      const timer = setTimeout(() => {
        setShow(false);
        onHide?.();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onHide]);

  if (!show) return null;

  return (
    <div className="fixed inset-x-0 top-0 z-50 flex justify-center pt-2 px-3 sm:pt-4 sm:px-4 pointer-events-none">
      <div className="animate-scale-in bg-gradient-to-r from-green-500 via-emerald-500 to-green-600 rounded-3xl p-5 sm:p-7 shadow-2xl border-3 border-green-200 max-w-sm pointer-events-auto">
        <div className="text-center">
          <div className="text-5xl sm:text-6xl mb-2 sm:mb-3">✅</div>
          <h3 className="text-2xl sm:text-3xl font-black text-white mb-1">
            Acertou em cheio! 🔥
          </h3>
          <p className="text-base sm:text-lg text-green-50 font-bold">
            Continue assim, tá indo bem!
          </p>
        </div>
      </div>
    </div>
  );
}
